import { useState, useEffect, useRef } from "react";
import { Send, Hash, Settings, User, LogOut, Shield, Trash2, Plus, MessageSquare, Palette, Type, Sparkles, Paintbrush } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const FONTS = [
  "Adios Script Pro", "Affair", "Aphrodite Pro", "Belluccia Pro", "Burges Script",
  "Cantoni Pro", "Carolyna Pro Black", "Feel Script", "Melany Lane", "Parfumerie Script",
  "Vunder Script™", "Halo Handletter", "Parisienne", "Nickainley", "Samantha Brandon Handwritten Font",
  "Canva", "Canva +3", "Sophisticated Serif & Display Fonts", "Instrument Serif", "Playfair Display",
  "Bodoni Moda", "Didot", "Cormorant", "EB Garamond", "Libre Baskerville", "Royalis",
  "Royal Affair", "Bauer Bodoni", "Alberobello Serif", "Ginetta Marriage Serif Font",
  "Stardust Celestina Modern Serif Font", "Le Murmure", "Mazius Display"
];

const COLORS = [
  { name: "Cool Blue", hex: "#D7EFFF", desc: "A frosty, icy blue." },
  { name: "Jade", hex: "#AEB8A0", desc: "A serene, moody mint-moss green." },
  { name: "Plum Noir", hex: "#351E28", desc: "A deep, decadent dark purple." },
  { name: "Wasabi", hex: "#E9F056", desc: "An electric chartreuse neon." },
  { name: "Persimmon", hex: "#E2725B", desc: "A vibrant, warm orange-red." },
  { name: "Transformative Teal", hex: "#008080", desc: "A deep, eco-conscious teal." },
  { name: "Electric Fuchsia", hex: "#FD4FFF", desc: "A fluorescent, high-energy pink." },
  { name: "Blue Aura", hex: "#A0B0C0", desc: "A soft, hazy, pastel-gray blue." },
  { name: "Amber Haze", hex: "#FFBF00", desc: "A glowing, warm yellow-amber." },
  { name: "Jelly Mint", hex: "#A0E6DA", desc: "A bright, fresh, minty green." },
  { name: "Mocha Mousse", hex: "#A47864", desc: "A rich, warm, earthy brown." },
  { name: "Cloud Dancer", hex: "#F0EFE9", desc: "A warm, airy, off-white." },
  { name: "Universal Khaki", hex: "#C2B280", desc: "A versatile, mid-tone tan." },
  { name: "Cocoa Powder", hex: "#4B3621", desc: "A deep, dark brown alternative to black." },
  { name: "Sage Green", hex: "#9CACA0", desc: "A soft, natural, calming green." },
  { name: "Terracotta Red", hex: "#E2725B", desc: "A sun-baked, clay-like, rust color." },
  { name: "Warm Taupe", hex: "#A09080", desc: "A gentle, grounded gray-brown." },
  { name: "Almond", hex: "#EFDECD", desc: "A warm, soft, neutral cream." },
  { name: "Dusty Rose", hex: "#D58D8D", desc: "A muted, mature, pink-beige." },
  { name: "Burnt Sienna", hex: "#E97451", desc: "A rusty, earthy red-brown." },
  { name: "Digital Lavender", hex: "#A78BFA", desc: "A serene, tech-inspired purple." },
  { name: "Verdant Green", hex: "#4CAF50", desc: "A vibrant, emerald-like green." },
  { name: "Sunny Yellow", hex: "#FFDD44", desc: "A bold, high-contrast, nostalgic yellow." },
  { name: "Neon Magenta", hex: "#FF00FF", desc: "A high-voltage, digital pop color." },
  { name: "Cyber Blue", hex: "#0000FF", desc: "A standard, high-contrast blue screen color." },
  { name: "Midnight Blue", hex: "#101585", desc: "A deep, luxurious navy." },
  { name: "Charcoal", hex: "#333333", desc: "A dark, soft alternative to absolute black." },
  { name: "Pearlescent Purple", hex: "#C3B1E1", desc: "An iridescent, dreamy shade." },
  { name: "Mineral Blue", hex: "#48AAAD", desc: "A clear, saturated, ocean blue." },
  { name: "Burnished Lilac", hex: "#A295C1", desc: "A smoky, vintage-modern lavender." }
];

const ANIMATIONS = [
  "Kinetic Type", "Handwriting Signature", "Glitch Reveal", "Morphing Shape", "3D Pop-up",
  "Gradient Stroke", "Neon Glow", "Slide & Fade", "Liquid Morph", "Typewriter Effect",
  "Paper Plane Reveal", "Rotating Cube", "Particles/Dust Formation", "Draw-on (SVG)",
  "Layered 3D Extrusion", "Stop-Motion Effect", "Zoom-In/Zoom-Out", "Scan Line Reveal",
  "Elastic/Bounce", "Wave/Wavy Movement"
];

const GRADIENTS = [
  "Electric Magenta to Deep Blue", "Incandescent Red to Electric Orange", "Neon Cyan to Deep Purple",
  "Acid Yellow (Wasabi) to Charcoal", "Neon Green on Black", "Pearlescent Purple to Soft Teal",
  "Iridescent Aqua to Silver", "Mint Green to Dusty Rose", "Lavender Blue to Icy White",
  "Cyan to Soft Magenta", "Tangerine Orange to Warm Rust", "Butter Yellow to Deep Mocha",
  "Dusty Pink to Warm Gray", "Cream to Dark Cocoa", "Terracotta to Sand",
  "Emerald Green to Deep Teal", "Deep Sapphire to Royal Purple", "Ocean Blue to Deep Aqua",
  "Magenta to Hot Pink", "White to Light Gray (with neon glow)"
];

type Message = {
  id: number;
  channelId: number;
  username: string;
  content: string;
  role: string;
  roleColor: string;
  timestamp: string;
};

type Channel = {
  id: number;
  name: string;
};

export default function Chat() {
  const [user, setUser] = useState<{ username: string; role: string; isAdmin: boolean } | null>(null);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [channels, setChannels] = useState<Channel[]>([]);
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const { toast } = useToast();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const saved = localStorage.getItem("horizon_chat_user");
    if (saved) setUser(JSON.parse(saved));
    fetchChannels();
  }, []);

  useEffect(() => {
    if (activeChannel) fetchMessages(activeChannel.id);
  }, [activeChannel]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const fetchChannels = async () => {
    const res = await fetch("/api/chat/channels");
    const data = await res.json();
    setChannels(data);
    if (data.length > 0 && !activeChannel) setActiveChannel(data[0]);
  };

  const fetchMessages = async (channelId: number) => {
    const res = await fetch(`/api/chat/channels/${channelId}/messages`);
    const data = await res.json();
    setMessages(data);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/chat/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (res.ok) {
      setUser(data);
      localStorage.setItem("horizon_chat_user", JSON.stringify(data));
      toast({ title: "Welcome to HORIZON CHAT" });
    } else {
      toast({ title: data.message, variant: "destructive" });
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user || !activeChannel) return;

    const res = await fetch(`/api/chat/channels/${activeChannel.id}/messages`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: newMessage, username: user.username }),
    });
    if (res.ok) {
      setNewMessage("");
      fetchMessages(activeChannel.id);
    }
  };

  if (!user) {
    return (
      <div className="flex flex-col h-full bg-black items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md bg-white/[0.02] border border-white/10 rounded-3xl p-8 backdrop-blur-xl">
          <h1 className="text-4xl font-display font-black text-center mb-8 text-gradient-animated tracking-widest uppercase">HORIZON CHAT</h1>
          <form onSubmit={handleLogin} className="space-y-6">
            <Input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="bg-black/50 border-white/10 h-12" required />
            <Input type="password" placeholder="Password (Optional for Users)" value={password} onChange={(e) => setPassword(e.target.value)} className="bg-black/50 border-white/10 h-12" />
            <Button type="submit" className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-display text-lg rounded-xl">SIGN IN</Button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="flex h-full bg-black text-white overflow-hidden">
      {/* Channels Sidebar */}
      <div className="w-64 border-r border-white/5 bg-black/50 flex flex-col hidden md:flex">
        <div className="p-4 border-b border-white/5 flex items-center justify-between">
          <h2 className="font-display font-bold text-lg tracking-widest text-gradient-animated">CHANNELS</h2>
          {user.isAdmin && <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-white"><Plus className="w-4 h-4" /></Button>}
        </div>
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {channels.map((ch) => (
              <button key={ch.id} onClick={() => setActiveChannel(ch)} className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${activeChannel?.id === ch.id ? 'bg-primary/10 text-primary border border-primary/20' : 'text-muted-foreground hover:bg-white/5 hover:text-white'}`}>
                <Hash className="w-4 h-4" />
                <span className="font-medium">{ch.name}</span>
              </button>
            ))}
          </div>
        </ScrollArea>
        <div className="p-4 border-t border-white/5 bg-black/80">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center bg-primary/20 border border-primary/30 ${user.isAdmin ? 'animate-pulse' : ''}`}>
              <User className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className={`font-bold truncate ${user.isAdmin ? 'text-gradient-animated' : 'text-white'}`}>{user.username}</p>
              <p className="text-xs text-muted-foreground truncate">{user.role}</p>
            </div>
            <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground hover:text-white" onClick={() => { setUser(null); localStorage.removeItem("horizon_chat_user"); }}><LogOut className="w-4 h-4" /></Button>
          </div>
          {user.isAdmin && (
            <Button variant="outline" className="w-full mt-4 border-primary/30 hover:bg-primary/10 text-primary gap-2" onClick={() => setShowAdminPanel(!showAdminPanel)}>
              <Shield className="w-4 h-4" /> Admin Panel
            </Button>
          )}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col bg-black relative">
        <header className="h-16 border-b border-white/5 flex items-center px-6 justify-between bg-black/50 backdrop-blur-md z-10">
          <div className="flex items-center gap-2">
            <Hash className="w-5 h-5 text-muted-foreground" />
            <h2 className="font-bold text-xl">{activeChannel?.name || "Select a channel"}</h2>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
              <span className="text-xs font-mono text-muted-foreground">ONLINE</span>
            </div>
          </div>
        </header>

        <div className="flex-1 relative overflow-hidden flex">
          <ScrollArea className="flex-1 px-6 py-4" ref={scrollRef}>
            <div className="space-y-6">
              {messages.map((msg) => (
                <div key={msg.id} className="group flex flex-col gap-1 hover:bg-white/[0.02] -mx-6 px-6 py-2 transition-all">
                  <div className="flex items-baseline gap-3">
                    <span className={`font-black tracking-wide ${msg.username === "RandomIX" ? 'text-gradient-animated text-lg' : ''}`} style={{ color: msg.roleColor }}>{msg.username}</span>
                    <span className="text-[10px] text-muted-foreground/50 font-mono">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/5 border border-white/5 text-muted-foreground uppercase tracking-widest">{msg.role}</span>
                  </div>
                  <p className="text-white/90 leading-relaxed font-sans">{msg.content}</p>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Admin Tools Drawer (if shown) */}
          <AnimatePresence>
            {showAdminPanel && (
              <motion.div initial={{ x: 300 }} animate={{ x: 0 }} exit={{ x: 300 }} className="w-80 border-l border-white/5 bg-black/90 backdrop-blur-xl absolute right-0 inset-y-0 z-20 shadow-2xl p-6">
                <h3 className="font-display font-black text-xl mb-6 text-gradient-animated tracking-widest">MASTER CONTROL</h3>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Management</label>
                    <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><MessageSquare className="w-4 h-4" /> Manage Channels</Button>
                    <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Settings className="w-4 h-4" /> Server Settings</Button>
                    <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Shield className="w-4 h-4" /> Roles & Permissions</Button>
                  </div>
                  <div className="space-y-4">
                    <label className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Customization</label>
                    <div className="grid grid-cols-1 gap-2">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Type className="w-4 h-4" /> 30 Fanciest Fonts</Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black border-white/10 max-w-2xl max-h-[80vh]">
                          <DialogHeader><DialogTitle className="text-gradient-animated font-display">THE FANCIEST FONTS</DialogTitle></DialogHeader>
                          <ScrollArea className="h-full pr-4">
                            <div className="grid grid-cols-2 gap-2 p-1">
                              {FONTS.map((font, i) => (
                                <Button key={i} variant="ghost" className="justify-start h-auto py-3 text-white/70 hover:text-white hover:bg-white/5 font-sans">
                                  {i + 1}. {font}
                                </Button>
                              ))}
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>

                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Palette className="w-4 h-4" /> 30 Master Colors</Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black border-white/10 max-w-2xl max-h-[80vh]">
                          <DialogHeader><DialogTitle className="text-gradient-animated font-display">MASTER COLORS</DialogTitle></DialogHeader>
                          <ScrollArea className="h-full pr-4">
                            <div className="grid grid-cols-1 gap-2 p-1">
                              {COLORS.map((color, i) => (
                                <div key={i} className="flex items-center gap-4 p-3 rounded-xl bg-white/5 border border-white/5 group hover:border-primary/50 transition-all">
                                  <div className="w-10 h-10 rounded-lg shadow-lg" style={{ backgroundColor: color.hex }} />
                                  <div>
                                    <p className="font-bold text-white">{color.name} <span className="text-xs font-mono text-muted-foreground ml-2">{color.hex}</span></p>
                                    <p className="text-xs text-muted-foreground italic">{color.desc}</p>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>

                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Sparkles className="w-4 h-4" /> 20 Elite Animations</Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black border-white/10 max-w-2xl max-h-[80vh]">
                          <DialogHeader><DialogTitle className="text-gradient-animated font-display">ELITE ANIMATIONS</DialogTitle></DialogHeader>
                          <ScrollArea className="h-full pr-4">
                            <div className="grid grid-cols-1 gap-2 p-1">
                              {ANIMATIONS.map((anim, i) => (
                                <Button key={i} variant="ghost" className="justify-start h-12 text-white/70 hover:text-white hover:bg-white/5 px-4 rounded-xl border border-white/5">
                                  <span className="w-6 text-primary font-mono text-xs">{i + 1}</span> {anim}
                                </Button>
                              ))}
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>

                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="w-full justify-start gap-3 border-white/10 hover:bg-white/5"><Paintbrush className="w-4 h-4" /> 20 Color through Color</Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black border-white/10 max-w-2xl max-h-[80vh]">
                          <DialogHeader><DialogTitle className="text-gradient-animated font-display">COLOR THROUGH COLOR</DialogTitle></DialogHeader>
                          <ScrollArea className="h-full pr-4">
                            <div className="grid grid-cols-1 gap-2 p-1">
                              {GRADIENTS.map((grad, i) => (
                                <Button key={i} variant="ghost" className="justify-start h-14 text-white/70 hover:text-white hover:bg-white/5 px-4 rounded-xl border border-white/5 group">
                                  <span className="w-6 text-primary font-mono text-xs">{i + 1}</span> 
                                  <span className="text-gradient-animated font-bold tracking-tight">{grad}</span>
                                </Button>
                              ))}
                            </div>
                          </ScrollArea>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="p-6 bg-black border-t border-white/5">
          <form onSubmit={handleSendMessage} className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600/20 to-purple-600/20 rounded-2xl blur opacity-25 group-focus-within:opacity-50 transition duration-500" />
            <div className="relative flex items-center gap-3">
              <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder={`Message #${activeChannel?.name || 'chat'}`} className="flex-1 bg-black/50 border-white/10 h-14 rounded-2xl text-white placeholder:text-muted-foreground focus-visible:ring-primary transition-all pr-12" />
              <Button type="submit" size="icon" className="absolute right-2 h-10 w-10 bg-primary hover:bg-primary-hover rounded-xl text-white transition-all">
                <Send className="w-5 h-5" />
              </Button>
            </div>
          </form>
          <p className="mt-3 text-[10px] text-muted-foreground font-mono uppercase tracking-[0.2em] text-center">HORIZON ENCRYPTED BROADCAST PROTOCOL</p>
        </div>
      </div>
    </div>
  );
}
