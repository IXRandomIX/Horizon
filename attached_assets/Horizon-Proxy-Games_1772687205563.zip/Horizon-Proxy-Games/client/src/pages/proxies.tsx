import { Globe, Shield } from "lucide-react";
import { motion } from "framer-motion";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const PROXIES = [
  { name: "Interstellar", url: "https://ad-free-proxy--securlyeduclass.replit.app/", desc: "High-speed encrypted tunnel" },
  { name: "Lunaar", url: "https://vps-d38e82a1.vps.ovh.us/", desc: "Optimized low-latency connection" },
  { name: "Platinum", url: "https://the.chicanoveterans.org/@", desc: "Premium grade secure bypass" }
];

export default function Proxies() {
  return (
    <div className="flex flex-col h-full bg-black overflow-y-auto custom-scrollbar p-6 md:p-12">
      <div className="max-w-6xl mx-auto w-full">
        <h1 className="text-4xl md:text-6xl font-display font-black text-white mb-12 text-gradient-animated tracking-widest uppercase text-center">
          Proxies
        </h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {PROXIES.map((proxy, i) => (
            <motion.div
              key={proxy.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="bg-white/[0.03] border-white/10 hover:border-primary/50 transition-all group h-full flex flex-col">
                <CardHeader>
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4 border border-primary/20 group-hover:scale-110 transition-transform">
                    <Shield className="w-6 h-6 text-primary" />
                  </div>
                  <CardTitle className="text-2xl text-white font-display tracking-wide">{proxy.name}</CardTitle>
                  <CardDescription className="text-muted-foreground">{proxy.desc}</CardDescription>
                </CardHeader>
                <CardContent className="mt-auto pt-6">
                  <Button 
                    className="w-full bg-white/5 hover:bg-primary hover:text-white border-white/10 transition-all rounded-xl h-12"
                    onClick={() => window.open(proxy.url, '_blank')}
                  >
                    Establish Connection
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
