import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const dummyTable = pgTable("dummy", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id").notNull(),
  username: text("username").notNull(),
  content: text("content").notNull(),
  role: text("role").default("User"),
  roleColor: text("role_color").default("#9ca3af"),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"), // Only for admin
  role: text("role").default("User"),
  roleColor: text("role_color").default("#9ca3af"),
  animation: text("animation").default("none"),
  font: text("font").default("sans"),
});

export const insertChannelSchema = createInsertSchema(channels).omit({ id: true });
export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, timestamp: true });
export const insertUserSchema = createInsertSchema(users).omit({ id: true });

export type Channel = typeof channels.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type User = typeof users.$inferSelect;
