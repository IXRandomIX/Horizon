import { db } from "./db";
import { dummyTable, channels, messages, users, type Channel, type Message, type User, type InsertDummy } from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getDummies(): Promise<any[]>;
  createDummy(dummy: any): Promise<any>;
  
  getChannels(): Promise<Channel[]>;
  createChannel(name: string): Promise<Channel>;
  
  getMessages(channelId: number): Promise<Message[]>;
  createMessage(msg: any): Promise<Message>;
  
  getUser(username: string): Promise<User | undefined>;
  createUser(user: any): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  async getDummies(): Promise<any[]> {
    return await db.select().from(dummyTable);
  }

  async createDummy(dummy: any): Promise<any> {
    const [inserted] = await db.insert(dummyTable).values(dummy).returning();
    return inserted;
  }

  async getChannels(): Promise<Channel[]> {
    return await db.select().from(channels);
  }

  async createChannel(name: string): Promise<Channel> {
    const [inserted] = await db.insert(channels).values({ name }).returning();
    return inserted;
  }

  async getMessages(channelId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.channelId, channelId));
  }

  async createMessage(msg: any): Promise<Message> {
    const [inserted] = await db.insert(messages).values(msg).returning();
    return inserted;
  }

  async getUser(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: any): Promise<User> {
    const [inserted] = await db.insert(users).values(user).returning();
    return inserted;
  }
}

export const storage = new DatabaseStorage();
