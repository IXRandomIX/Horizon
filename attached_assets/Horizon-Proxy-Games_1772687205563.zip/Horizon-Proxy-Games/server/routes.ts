import type { Express } from "express";
import type { Server } from "http";
import { api } from "@shared/routes";
import { storage } from "./storage";

// Define a basic caching mechanism to avoid excessive fetching
let cachedGames: any[] = [];
let lastFetchTime = 0;
const CACHE_DURATION = 1000 * 60 * 60; // 1 hour

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Create default channel if none exists
  const setupChat = async () => {
    const channels = await storage.getChannels();
    if (channels.length === 0) {
      await storage.createChannel("general");
      await storage.createChannel("announcements");
      await storage.createChannel("lounge");
    }
  };
  setupChat();

  app.get(api.games.list.path, async (req, res) => {
    try {
      const now = Date.now();
      if (cachedGames.length > 0 && now - lastFetchTime < CACHE_DURATION) {
        return res.json(cachedGames);
      }
      const response = await fetch("https://cdn.jsdelivr.net/gh/gn-math/assets@main/zones.json");
      if (!response.ok) throw new Error("Failed to fetch games data");
      const data = await response.json();
      const coverUrl = "https://cdn.jsdelivr.net/gh/gn-math/covers@main";
      const htmlUrl = "https://cdn.jsdelivr.net/gh/gn-math/html@main";
      const formattedGames = data.filter((game: any) => game.id >= 0 && game.url && game.name).map((game: any) => {
        let url = game.url || "";
        let cover = game.cover || "";
        url = url.replace("{HTML_URL}", htmlUrl);
        cover = cover.replace("{COVER_URL}", coverUrl);
        return { id: game.id, name: game.name, cover: cover, url: url, author: game.author, authorLink: game.authorLink };
      });
      cachedGames = formattedGames;
      lastFetchTime = now;
      res.json(cachedGames);
    } catch (err) {
      res.status(500).json({ message: "Failed to fetch games" });
    }
  });

  // Chat Routes
  app.get("/api/chat/channels", async (req, res) => {
    const channels = await storage.getChannels();
    res.json(channels);
  });

  app.get("/api/chat/channels/:channelId/messages", async (req, res) => {
    const messages = await storage.getMessages(Number(req.params.channelId));
    res.json(messages);
  });

  app.post("/api/chat/channels/:channelId/messages", async (req, res) => {
    const { content, username } = req.body;
    const user = await storage.getUser(username);
    const msg = await storage.createMessage({
      channelId: Number(req.params.channelId),
      username,
      content,
      role: user?.role || "User",
      roleColor: user?.roleColor || "#9ca3af"
    });
    res.status(201).json(msg);
  });

  app.post("/api/chat/auth/login", async (req, res) => {
    const { username, password } = req.body;
    const ADMIN_USER = "RandomIX";
    const ADMIN_PASS = "AdminWorks1717!!!TotallyGatekeeped!!!@@@";

    if (username === ADMIN_USER) {
      if (password === ADMIN_PASS) {
        let user = await storage.getUser(username);
        if (!user) {
          user = await storage.createUser({
            username,
            password: ADMIN_PASS,
            role: "Owner",
            roleColor: "#a855f7",
            animation: "glitch",
            font: "fancy"
          });
        }
        return res.json({ username: user.username, role: "Owner", isAdmin: true });
      } else {
        return res.status(401).json({ message: "Invalid admin credentials" });
      }
    }

    let user = await storage.getUser(username);
    if (!user) {
      user = await storage.createUser({ username, role: "User", roleColor: "#9ca3af" });
    }
    res.json({ username: user.username, role: user.role, isAdmin: false });
  });

  return httpServer;
}
